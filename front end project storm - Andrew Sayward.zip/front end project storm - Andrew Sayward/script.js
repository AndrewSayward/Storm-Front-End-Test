$(document).ready(function(){

    $("#signUpBTN").click(function(){
        $(".popUp").css("display","block");
    });
    
    $(".close").click(function(){
        $(".popUp").css("display","none");
    });
      
});